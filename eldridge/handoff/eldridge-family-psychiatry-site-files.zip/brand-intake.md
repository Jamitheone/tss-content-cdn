# Eldridge Family Psychiatry & Wellness — Brand Intake (submitted 2026-07-10, GHL note)

Client: Olga Eldridge, PMHNP-BC (address her as "Olga", not "Dr.")
Business: Eldridge Family Psychiatry & Wellness, LLC · St. Louis MO · telehealth across ALL of Missouri
Contact: eldridge.olga84@gmail.com · 417-818-5506 · current site eldridgefamilypsychiatry.org (Wix, being replaced; she may move to .com)

## What she does
Telepsychiatry for ALL mental health conditions, ages 4-99. NOT just ADHD (she explicitly corrected this). Depression, anxiety, ADHD, bipolar, OCD, PTSD/trauma, insomnia, schizophrenia/psychotic disorders, addiction/substance use. Compassionate, judgment-free care.

## Voice / vibe
Warm, Professional, Calm, Approachable, Clinical/Trusted. Never robotic, rushed, fear-based, guilt-based, or jargon-heavy. "Talking WITH people, not at them." Site should feel like "a deep breath." Personal, never cold/corporate/transactional. Visitor's takeaway: "I finally found someone who understands — and there's hope."

## Colors
LOVE: soft sage green, deep forest green, warm ivory, muted blue, charcoal, subtle gold accents. Timeless, understated.
HATE: neons, saturated reds, fluorescent greens, bold oranges, chaotic/trendy combos.

## Sites she admires
- apple.com — clean, intentional, uncluttered
- headspace.com — warm, calming, makes mental health less intimidating
- hims.com — professional, plain-language healthcare, smooth patient journey

## Logo / photos
Has a logo she loves (GET FILE FROM HER). Needs a professional welcoming photo of her (ASK — placeholder until then). No stock photos: Higgsfield brand-matched visuals per TSS rule.

## Must include
- Credentials: Olga Eldridge, PMHNP-BC, Board-Certified Psychiatric-Mental Health Nurse Practitioner
- Online appointment scheduling button (strong CTA on every page)
- Insurance list + note "additional insurance plans continually being added" + self-pay pricing:
  - New Patient Psychiatric Evaluation (self-pay): $300
  - Follow-Up Medication Management (self-pay): $150
- Secure patient portal link (Carepatron — NEVER mention Optimantra, that was wrong)
- Telepsychiatry / care-from-home info
- Conditions treated + services overview
- Treatment philosophy: compassionate, personalized, evidence-based, patient is an active partner
- Statement: stimulant medications and other controlled substances available when clinically appropriate after comprehensive evaluation
- Contact info, office hours, FAQs
- Testimonials section (compliant placeholder ok)

## Do NOT
- Cluttered pages, confusing nav, overly clinical language
- Flashy animations, pop-ups, salesy pressure
- Cold/corporate/transactional feel
- ADHD-only positioning

## Origin story (use for About)
Nurse → PMHNP. "What many people needed most wasn't just medication — they needed someone who would truly listen." Started the practice so people feel genuinely cared for, never judged, never rushed. Drives her: watching someone rediscover themselves. Differentiator: care starts with listening, not a prescription; collaborative treatment plans; every patient leaves feeling heard, respected, hopeful.

## Ideal patient problem
"Wanting to feel like themselves again." Objections to overcome: "Will this provider really listen? Will I feel judged? Will treatment actually help? Is it worth the investment?"

## Primary actions
Book appointment, fill form, call/text, learn more.

## Socials
Facebook, Pinterest (open to others).

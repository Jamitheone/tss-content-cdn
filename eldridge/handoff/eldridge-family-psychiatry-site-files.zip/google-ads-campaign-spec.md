# Eldridge Family Psychiatry — Google Ads Launch Spec (2026-07-10)

Client: Olga Eldridge, PMHNP-BC. Full OS $1,200/mo (ads management included). Ad spend: $1,000/mo, billed separately via Stripe link, TSS runs the media buy.

## Hard rules
- HIPAA: market the PRACTICE, never target or imply knowledge of patient conditions. No remarketing lists, no health-condition audience segments (Google prohibits personalized ads for health anyway — expect limited audience features on this account).
- NOT ADHD-only. ADHD medication management is the spearhead keyword set (highest intent, her unique supply: collaborator prescribes ADHD meds, rare in MO), but ad copy and landing pages must read all-conditions, ages 4-99.
- Telehealth statewide Missouri. Geofence: Missouri (state-level location target, "Presence: people in or regularly in").

## Account setup
- New Google Ads account under TSS manager (MCC) — billing = TSS card (payments flow through TSS, never client card into Google).
- Conversion actions (both Primary): form submit + phone click. One-char label typo silently zeroes conversions — verify exact label string in production HTML after deploy.
- Landing page: new site (eldridge-psychiatry repo). Until live, .org Wix site is the fallback — but launch on the new site if at all possible, Wix page has no conversion tags.

## Campaign 1 — Search: ADHD Medication Management (spearhead, ~$600/mo)
Keywords (phrase/exact):
- "adhd medication management" / "adhd psychiatrist near me" / "adhd nurse practitioner"
- "adhd treatment missouri" / "adhd medication online missouri" / "adhd telehealth missouri"
- "adderall prescriber missouri" — CHECK POLICY: prescription drug terms may require Google healthcare cert; if disapproved, drop drug-name terms, keep condition-service terms.
Negatives: free, cheap, jobs, career, school (job seekers), "for teachers", veterinary.

Ad copy (RSA) — all-conditions framing, ADHD-leaning headlines allowed but never exclusive:
- H: ADHD Medication Management | Psychiatric Care, Ages 4-99 | Telehealth Across Missouri | New Patients Welcome | Board-Certified PMHNP | Compassionate Mental Health Care
- D: Comprehensive psychiatric evaluation and medication management for children, teens, and adults. Telehealth appointments statewide in Missouri. Most insurance accepted.
- D: ADHD, anxiety, depression, and more. Warm, judgment-free care from a board-certified psychiatric nurse practitioner.

## Campaign 2 — Search: General Psychiatry (~$400/mo)
Keywords: "psychiatrist near me", "psychiatric nurse practitioner missouri", "medication management near me", "child psychiatrist missouri", "telehealth psychiatry missouri", "anxiety treatment missouri", "depression medication missouri"
Same negatives + "therapy only" intent terms if they waste spend (watch search terms weekly).

## Budget math
$1,000/mo ≈ $33/day. Split: $20/day ADHD spearhead, $13/day general. Psychiatry CPCs in MO ~$4-8 → ~150-250 clicks/mo → at 5-8% conversion, 8-20 leads/mo. Solo provider capacity check: throttle spend if she's booked out (churn risk per enterprise-fit rule).

## Launch checklist
- [ ] Google Ads account created under TSS MCC, TSS card on billing
- [ ] Conversion tags live on new site + verified (exact label strings)
- [ ] Both campaigns built, MO geofence, telehealth ad schedule (her availability hours)
- [ ] Drug-name keyword policy check passed or terms dropped
- [ ] Speed-to-lead automation live on her sub-account BEFORE first ad dollar

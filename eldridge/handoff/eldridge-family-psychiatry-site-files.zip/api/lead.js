// Website contact form -> GHL contact + opportunity (Patient Pipeline, New Inquiry).
// Fixes the gap where the form only emailed and never created a tracked lead in the CRM.
// ponytail: raw fetch, no SDK. IDs in env with hard fallbacks so a missing env var can't silently break it.
const BASE = "https://services.leadconnectorhq.com";
const TOKEN = process.env.GHL_OLGA_API_TOKEN;
const LOCATION = process.env.GHL_OLGA_LOCATION_ID || "NrAR9P6NhHcVXjkPClO0";
const PIPELINE = process.env.GHL_OLGA_PIPELINE_ID || "Ur9e24npSPQoADwlZsEe";
const STAGE_NEW = process.env.GHL_OLGA_STAGE_NEW || "d224a44c-1722-4c2b-bcbe-b71d131c3842";

async function ghl(method, path, body, ver = "2021-07-28") {
  const r = await fetch(BASE + path, {
    method,
    headers: {
      Authorization: "Bearer " + TOKEN,
      Version: ver,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await r.text();
  let json = {};
  try { json = text ? JSON.parse(text) : {}; } catch { json = { raw: text }; }
  return { status: r.status, json };
}

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  if (!TOKEN) return res.status(500).json({ error: "server not configured" });

  const b = req.body || {};
  if (b._honey) return res.status(200).json({ ok: true });

  const name = (b.name || "").trim();
  const email = (b.email || "").trim();
  const phone = (b.phone || "").trim();
  const message = (b.message || "").trim();
  if (!name || !email) return res.status(400).json({ error: "name and email required" });

  const [firstName, ...rest] = name.split(" ");
  const lastName = rest.join(" ");

  try {
    const up = await ghl("POST", "/contacts/upsert", {
      locationId: LOCATION,
      firstName,
      lastName,
      email,
      source: "Website Contact Form",
      tags: ["website-lead"],
    });
    const contactId = up.json?.contact?.id;
    if (!contactId) return res.status(502).json({ error: "contact upsert failed", detail: up.json });

    if (phone) await ghl("PUT", `/contacts/${contactId}`, { phone });

    const opp = await ghl("POST", "/opportunities/", {
      locationId: LOCATION,
      pipelineId: PIPELINE,
      pipelineStageId: STAGE_NEW,
      name: name,
      status: "open",
      contactId,
      source: "Website Contact Form",
    });

    if (message) {
      await ghl("POST", `/contacts/${contactId}/notes`, {
        body: `Website message: ${message}`,
        userId: contactId,
      });
    }

    return res.status(200).json({ ok: true, contactId, opportunity: opp.json?.opportunity?.id || opp.status });
  } catch (e) {
    return res.status(500).json({ error: "lead capture failed", detail: String(e) });
  }
};

"""Verify the Eldridge business card QR code and theme colors are correct.

Run: python3 test_business_card.py
Requires zbarimg (brew install zbar) to decode the QR image.
"""
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent
CARD_HTML = HERE / "business-card.html"
QR_PNG = HERE / "qr-code.png"
SITE_CSS = HERE.parent.parent / "css" / "style.css"

EXPECTED_URL = "https://eldridgefamilypsychiatry.org"


def test_qr_decodes_to_site_url():
    out = subprocess.run(
        ["zbarimg", "--quiet", str(QR_PNG)],
        capture_output=True, text=True, check=True,
    ).stdout.strip()
    assert out == f"QR-Code:{EXPECTED_URL}", f"unexpected QR payload: {out!r}"


def test_card_colors_match_site_theme():
    site_vars = dict(re.findall(r"--(\w[\w-]*):\s*(#[0-9A-Fa-f]{6})", SITE_CSS.read_text()))
    card_html = CARD_HTML.read_text()
    for key in ("forest", "sage", "teal", "gold", "ivory", "charcoal"):
        assert site_vars[key] in card_html, f"card is missing site color --{key} ({site_vars[key]})"


def test_card_has_required_contact_fields():
    card_html = CARD_HTML.read_text()
    for needle in ("417-538-3460", "contact@eldridgefamilypsychiatry.org", "PMHNP-BC", "qr-code.png"):
        assert needle in card_html, f"card missing expected content: {needle}"


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS {t.__name__}")
    print(f"{len(tests)} passed")

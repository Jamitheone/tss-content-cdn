// Eldridge Family Psychiatry & Wellness — main.js
// Small, dependency-free interaction layer. Keep it simple for Von to edit.

// Carepatron booking lives on book.html (embedded scheduler, set 7/13 from Olga's links).
var CAREPATRON_PORTAL_URL = 'book.html';

document.addEventListener('DOMContentLoaded', function () {

  /* ---- Lenis smooth scroll: gentle inertia, "deep breath" pacing.
     Runs on native scroll so sticky elements + IntersectionObserver keep
     working. Skipped entirely for reduced-motion users; if the CDN fails
     the site just uses normal scrolling. ---- */
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var lenis = null;
  if (!reduceMotion && typeof Lenis !== 'undefined') {
    lenis = new Lenis({
      duration: 1.15,
      easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); }
    });
    var lenisRaf = function (time) { lenis.raf(time); requestAnimationFrame(lenisRaf); };
    requestAnimationFrame(lenisRaf);
    // Let Lenis own anchor scrolling (CSS smooth-behavior would double-animate)
    document.documentElement.style.scrollBehavior = 'auto';
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
      var href = link.getAttribute('href');
      if (href === '#') return; // placeholder CTAs handle their own clicks
      link.addEventListener('click', function (e) {
        var target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          lenis.scrollTo(target, { offset: -90 });
        }
      });
    });
  }

  /* ---- Hero ambient loop: nudge autoplay (some browsers suspend it),
     pause entirely for reduced-motion users (CSS swaps in the poster) ---- */
  var heroVideo = document.querySelector('.hero-bg-video video');
  if (heroVideo) {
    if (reduceMotion) {
      heroVideo.pause();
    } else if (heroVideo.paused) {
      heroVideo.play().catch(function () { /* poster stays, that's fine */ });
    }
  }

  /* ---- Footer year ---- */
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---- Sticky nav shadow: IO sentinel instead of a scroll listener ---- */
  var nav = document.getElementById('siteNav');
  var sentinel = document.getElementById('navSentinel');
  if (nav && sentinel && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      nav.classList.toggle('scrolled', !entries[0].isIntersecting);
    }).observe(sentinel);
  }

  /* ---- Mobile nav toggle ---- */
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      var isOpen = navLinks.classList.toggle('mobile-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    // Close mobile menu after tapping a link
    navLinks.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navLinks.classList.remove('mobile-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---- Subtle scroll-reveal (respects prefers-reduced-motion via CSS) ---- */
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var observer = new IntersectionObserver(function (entries) {
      // Siblings that arrive together cascade 90ms apart instead of popping at once
      var i = 0;
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.transitionDelay = (i++ * 90) + 'ms';
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });
    revealEls.forEach(function (el) { observer.observe(el); });
  } else {
    // Fallback: just show everything
    revealEls.forEach(function (el) { el.classList.add('is-visible'); });
  }

  /* ---- Conditions accordion: gently close the others so the list stays calm ---- */
  document.querySelectorAll('.condition-item').forEach(function (item) {
    item.addEventListener('toggle', function () {
      if (!item.open) return;
      document.querySelectorAll('.condition-item[open]').forEach(function (other) {
        if (other !== item) other.open = false;
      });
    });
  });

  /* ---- Carepatron portal wiring ---- */
  var portalLinks = document.querySelectorAll('#portalCta, .portal-link');
  if (CAREPATRON_PORTAL_URL) {
    portalLinks.forEach(function (el) {
      el.setAttribute('href', CAREPATRON_PORTAL_URL);
      if (/^https?:/.test(CAREPATRON_PORTAL_URL)) {
        el.setAttribute('target', '_blank');
        el.setAttribute('rel', 'noopener');
      }
    });
  } else {
    portalLinks.forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.preventDefault();
        // ponytail: placeholder until Olga's Carepatron portal URL is provided
        alert('The patient portal link is being set up. For now, please call or text 417-538-3460 and we’ll take care of you.');
      });
    });
  }

});

// Booking + call clicks -> GA4 events (bookings happen off-site on Carepatron/Headway,
// so this click is the only booking signal GA4 ever sees). Mark book_click as a key event.
document.addEventListener('click', function (e) {
  var a = e.target.closest && e.target.closest('a[href]');
  if (!a || typeof gtag !== 'function') return;
  var h = a.href;
  var provider = /carepatron\.com/.test(h) && !/help\.carepatron/.test(h) ? 'carepatron' : /headway\.co/.test(h) ? 'headway' : null;
  if (provider) gtag('event', 'book_click', { provider: provider, page: location.pathname, transport_type: 'beacon' });
  else if (h.indexOf('tel:') === 0) gtag('event', 'call_click', { page: location.pathname, transport_type: 'beacon' });
});
